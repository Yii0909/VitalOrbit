# VitalOrbit: astronaut self-health monitor (React + FastAPI)

Python (`backend/main.py`) owns the health rules, XP, drift detection and reports. React (`frontend/`) is the UI.

## Run
```bash
# terminal 1
cd backend && python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt && uvicorn main:app --reload --port 8000

# terminal 2
cd frontend && npm install && npm run dev      # open http://localhost:5173
```
API docs: http://localhost:8000/docs. Data is stored in `backend/data.json` (delete it to reset to demo data).

## Next steps
Add NASA source citations, a camera/image input, and replace data.json with SQLite.
